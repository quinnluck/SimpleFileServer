﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/*
 * Created by Quinn Luck for Proofpoint interview
 * Apr. 2017
 */

namespace SimpleFileSystem
{
    class Program
    {
        static void Main(string[] args)
        {
            // Intentionally left blank
        }
    }
}
